<project xmlns="http://maven.apache.org/POM/4.0.0"
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
        <!-- Остальные элементы остаются неизменными -->

        <dependencies>
        <!-- Остальные зависимости остаются неизменными -->

        <!-- Добавляем зависимость для работы с JPA (Java Persistence API) -->
        <dependency>
        <groupId>javax.persistence</groupId>
        <artifactId>javax.persistence-api</artifactId>
        <version>2.2</version>
        </dependency>
        </dependencies>
        </project>

        Cоздание классов для сущностей

        java

import javax.persistence.*;
import java.util.List;

@Entity
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    // Геттеры и сеттеры
}

@Entity
public class Group {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @OneToMany(mappedBy = "group")
    private List<Student> students;

    private int graduationYear;

    // Геттеры и сеттеры
}

@Entity
public class Course {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String description;

    @ManyToMany(mappedBy = "courses")
    private List<Group> groups;

    // Геттеры и сеттеры
}

        java

        import javax.persistence.EntityManager;
        import javax.persistence.EntityManagerFactory;
        import javax.persistence.Persistence;
        import javax.persistence.TypedQuery;
        import java.util.List;

public class CourseManager {

    private static final EntityManagerFactory ENTITY_MANAGER_FACTORY = Persistence
            .createEntityManagerFactory("hibernate-helloworld-example");

    public static List<Student> getStudentsByCourse(String courseName) {
        EntityManager em = ENTITY_MANAGER_FACTORY.createEntityManager();
        em.getTransaction().begin();

        TypedQuery<Student> query = em.createQuery(
                "SELECT s FROM Student s JOIN s.groups g JOIN g.courses c WHERE c.name = :courseName",
                Student.class
        );
        query.setParameter("courseName", courseName);
        List<Student> students = query.getResultList();

        em.getTransaction().commit();
        em.close();

        return students;
    }

    public static void main(String[] args) {
        EntityManager em = ENTITY_MANAGER_FACTORY.createEntityManager();
        em.getTransaction().begin();

        // Создаем студентов, курсы и группы, связываем их и сохраняем в базу данных

        em.getTransaction().commit();
        em.close();

        // Вызываем функцию и выводим результат
        List<Student> students = getStudentsByCourse("Название курса");
        System.out.println("Студенты, слушающие курс: " + students);
    }
}
